// state.js state.ts
//handles player state

import { upgradeLibrary } from "./data.js";

export let state: State

export const makeInitialState = (): State => ({
  resources: {
    amoeba: 0,
    RNA: 0,
    highestRNA: 0,
    kineticEnergy: 0,
    slamoClicks: 0,
  },

  stats: {
    clickPower: 1,
    slamoClickPower: 1,
    slamoBoost: 0,
    RNAPower: 0.01,

    entropyPerSecondPower: 1,

    cellResets: 0,

    critEffectiveness: 2,
    // 33% automator amoeba compared to normal click
    automatorEffectiveness: 0.33,
    clickCooldown: 0.5,
    slamoClickCooldown: 3,

    critChance: 0,
    critIIGuarantee: 0,

    // TODO: move elsewhere.
    g1EffectFormula: 1.025,
  },

  runtime: {
    timesClicked: 0,
    totalEntropyClicks: 0,
    lastClickTime: 0,
    lastSlamoClickTime: 0,
    formulaicEntropyClicks: 0,
    automatorTickCounter: 5,
  },

  upgradeState: Object.fromEntries(
    Object.values(upgradeLibrary).map((u) => [u.ID, { level: 0, bonusMax: 0 }]),
  ),

  milestoneState: {
    M1: { claimed: false },
    M2: { claimed: false },
    M3: { claimed: false },
  },

  flags: {
    unlocked: {
      slamo: false,
      theAutomator: false,
      cells: false,
    },
  },
  config: {
    ignoredStats: [],
    hideBoughtUpgrades: false,
  },
});

export interface resettableKeys {
  // TODO: fix the ARCHITECTURE MATEY
  cells: [
    resources: Array<keyof State["resources"]>,
    stats: Array<keyof State["stats"]>,
  ];
}

export interface State {
  resources: {
    amoeba: number;
    RNA: number;
    highestRNA: number;
    kineticEnergy: number;
    slamoClicks: number;
  };

  stats: {
    clickPower: number;
    slamoClickPower: number;
    slamoBoost: number;
    RNAPower: number;
        entropyPerSecondPower: number;
    cellResets: number;
    critEffectiveness: number;
    automatorEffectiveness: number;
    clickCooldown: number;
    slamoClickCooldown: number;
    critChance: number;
    critIIGuarantee: number;
    g1EffectFormula: number;
  };

  runtime: {
    timesClicked: number;
    totalEntropyClicks: number;
    lastClickTime: number;
    lastSlamoClickTime: number;
    formulaicEntropyClicks: number;
    automatorTickCounter: number;
  };

  upgradeState: Record<string, { level: number; bonusMax: number }>;

  milestoneState: Record<string, { claimed: boolean }>;

  flags: {
    unlocked: {
      slamo: boolean;
      theAutomator: boolean;
      cells: boolean;
    };
  };

  config: {
    ignoredStats: Array<string>;
    hideBoughtUpgrades: boolean;
  };
}

//! Please fix this, i cant be bothered to
export function replaceState(replaced: any) {
  state = replaced;
}
